import java.util.*;

/**
 * Clase que representa un plato.
 * @author: Julen Sáenz Ferrero
 */
public class Plato {
    protected String nombre;
    private Map<Ingrediente,Integer> ingredientes = new LinkedHashMap<>();
    private Set<Plato> platos = new HashSet<>();

    public Plato(String nombre){
        this.nombre = nombre;
    }

    public String getName(){
        return this.nombre;
    }

    public Map<Ingrediente,Integer> getIngredientes(){
        return this.ingredientes;
    }

    public Set<Plato> getPlatos(){
        return this.platos;
    }

    public boolean addIngrediente(Ingrediente ingrediente, int cantidad){
        if (!ingredientes.containsKey(ingrediente)){
            this.ingredientes.put(ingrediente, cantidad);
            return true;
        }
        return false;
    }

    public boolean addPlato(Plato plato){
        if (platos.contains(plato)) {
            return false;
        } else {
            platos.add(plato);
            return true;
        }
    }

    @Override
    public String toString() {
        Set<Alergeno> alergenos = this.getAlergenos();

        String str = "[Plato] " + this.nombre + ": INFORMACION NUTRICIONAL DEL PLATO"
        + " -> Valor energetico: " + String.format("%.2f", this.getTotalCalorías()).replace(',', '.') 
        + " kcal, Hidratos de carbono: " + String.format("%.2f", this.getTotalHidratosCarbono()).replace(',', '.')
        + " g, Grasas: " + String.format("%.2f", this.getTotalGrasasTotales()).replace(',', '.')
        + " g, Saturadas: " + String.format("%.2f", this.getTotalGrasasSaturadas()).replace(',', '.')
        + " g, Proteinas: " + String.format("%.2f", this.getTotalProteinas()).replace(',', '.')
        + " g, Azucares: " + String.format("%.2f", this.getTotalAzucares()).replace(',', '.')
        + " g, Fibra: " + String.format("%.2f", this.getTotalFibra()).replace(',', '.')
        + " g, Sodio: " + String.format("%.2f", this.getTotalSodio()).replace(',', '.') + " mg.";

        if (alergenos != null && !alergenos.isEmpty()) {
            str += " CONTIENE ";
            for (Alergeno alergeno : alergenos) {
                str += alergeno.toString() + ", ";
            }
            str = str.substring(0, str.length() - 2); // Eliminamos la coma y el espacio extra al final del String
        }

        return str;
    }

    public double getTotalCalorías(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getCalorías()*cant/100;
            else total += ing.infoNutricional.getCalorías()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalCalorías();
        }

        return total;
    }
    public double getTotalHidratosCarbono(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getHidratosCarbono()*cant/100;
            else total += ing.infoNutricional.getHidratosCarbono()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalHidratosCarbono();
        }

        return total;
    }
    public double getTotalGrasasTotales(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getGrasasTotales()*cant/100;
            else total += ing.infoNutricional.getGrasasTotales()*cant;
        }
        
        for(Plato plato : platos){
            total += plato.getTotalGrasasTotales();
        }

        return total;
    }
    public double getTotalGrasasSaturadas(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getGrasasSaturadas()*cant/100;
            else total += ing.infoNutricional.getGrasasSaturadas()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalGrasasSaturadas();
        }

        return total;
    }
    public double getTotalProteinas(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getProteínas()*cant/100;
            else total += ing.infoNutricional.getProteínas()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalProteinas();
        }

        return total;
    }
    public double getTotalAzucares(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getAzúcares()*cant/100;
            else total += ing.infoNutricional.getAzúcares()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalAzucares();
        }

        return total;
    }
    public double getTotalFibra(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getFibra()*cant/100;
            else total += ing.infoNutricional.getFibra()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalFibra();
        }

        return total;
    }
    public double getTotalSodio(){
        double total = 0;
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            Ingrediente ing = ingrediente.getKey();
            int cant = ingrediente.getValue();
            if (ing.infoNutricional.getName().equals("100 g")) total += ing.infoNutricional.getSodio()*cant/100;
            else total += ing.infoNutricional.getSodio()*cant;
        }
        for(Plato plato : platos){
            total += plato.getTotalSodio();
        }

        return total;
    }
    
    public Set<Alergeno> getAlergenos(){
        SortedSet<Alergeno> alergenos = new TreeSet<>();
        for(Map.Entry<Ingrediente, Integer> ingrediente : ingredientes.entrySet()){
            if(ingrediente.getKey().getAlergenos() != null)
                alergenos.addAll(ingrediente.getKey().getAlergenos());
        }
        for(Plato plato : platos){
            if(plato.getAlergenos() != null)
                alergenos.addAll(plato.getAlergenos());
        }

        return alergenos;
    }
}