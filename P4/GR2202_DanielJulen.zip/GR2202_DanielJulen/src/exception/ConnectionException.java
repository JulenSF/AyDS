package src.exception;

/**
 * Clase que representa una excepcion para la funcion connect de BlockChainNetwork.
 * 
 * Autor: Julen Sáenz Ferrero
 */
public class ConnectionException extends Exception {
    String message;
    public ConnectionException(String message) {
        this.message = "\u001B[31mConnectionException: " + message + "\u001B[0m";
    }

    @Override
    public String toString(){
        return this.message;
    }
}