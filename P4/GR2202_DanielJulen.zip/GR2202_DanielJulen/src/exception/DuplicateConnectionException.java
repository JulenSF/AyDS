package src.exception;

/**
 * Clase que extiende la excepcion para la funcion connect de BlockChainNetwork.
 * 
 * Autor: Julen Sáenz Ferrero
 */
public class DuplicateConnectionException extends ConnectionException {
    public DuplicateConnectionException(String message) {
        super(message);
    }
}