package src.message;
import src.blockchain_network.Node;

/**
 * Clase que representa una interfaz de mensajería de la BlockChainNetwork.
 * 
 * Autor: Profesores AyDS
 */
public interface IMessage{
    public String getMessage();
    public default void process(Node n){
        System.out.println("[" + n.fullname() + "]" +
                           " - Received notification - Nex Tx: " +
                           this.getMessage());
    }
}