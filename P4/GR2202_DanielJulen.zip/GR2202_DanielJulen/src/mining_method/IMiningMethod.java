package src.mining_method;
import src.blockchain_network.*;

/**
 * Clase que representa una interfaz de minería de bloques.
 * 
 * Autor: Profesores AyDS
 */
public interface IMiningMethod{
    String createHash(Block block);
    Block mineBlock(Transaction transaction, Block previousConfirmedBlock, String MinerKey);
}