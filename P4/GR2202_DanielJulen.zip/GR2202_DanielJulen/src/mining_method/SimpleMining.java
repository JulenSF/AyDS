package src.mining_method;
import src.blockchain_network.Block;
import src.blockchain_network.Transaction;
import src.utils.*;

/**
 * Clase que implementa un método de minado simple.
 * 
 * Autor: Julen Sáenz Ferrero
 */
public class SimpleMining implements IMiningMethod{
    public String createHash(Block block){
        String str = "" + block.getVersion();
        if(block.getPrevious() == null) str += BlockConfig.GENESIS_BLOCK;
        else str += block.getPrevious().getHash();
        str += block.getTimeStamp() + block.getDifficulty() + block.getNonce();
        return CommonUtils.sha256(str);
    }
    
    public Block mineBlock(Transaction transaction, Block previousConfirmedBlock, String MinerKey){
        Block block = new Block(MinerKey, transaction, previousConfirmedBlock);
        block.setHash(createHash(block));
        return block;
    }
}