package src.validate_method;
import src.blockchain_network.*;
import src.mining_method.*;


/**
 * Clase que representa una interfaz de validación de bloques.
 * 
 * Autor: Profesores AyDS
 */
public interface IValidateMethod{
    public boolean validate(IMiningMethod miningMethod, Block block);
}