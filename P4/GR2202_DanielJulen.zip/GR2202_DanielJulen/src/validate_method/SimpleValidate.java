package src.validate_method;
import src.blockchain_network.Block;
import src.mining_method.IMiningMethod;

/**
 * Clase que implementa un método de validación simple.
 * 
 * Autor: Julen Sáenz Ferrero
 */
public class SimpleValidate implements IValidateMethod{
    public boolean validate(IMiningMethod miningMethod, Block block){
        return(miningMethod.createHash(block).equals(block.getHash()));
    }
}