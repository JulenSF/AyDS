package objetos;
import registration.RegistrationStateCheck;
import java.util.*;

public class ObjectStateTracker<K, V> {
    /*private Map<K, V> objectStateMap;*/
    private Map<V, RegistrationStateCheck<K>> stateConditionsMap;
    private V defaultState;
    private Map<K, V> registerStatesMap;

    public ObjectStateTracker(V[] claves){
        stateConditionsMap = new HashMap<>();
        registerStatesMap = new HashMap<>();
        for (V clave : claves) {
            stateConditionsMap.put(clave, null);
        }
    }

    public void addObjects(K... objects) {
        for (K object : objects) {
            boolean foundState = false;
            for (Map.Entry<V, RegistrationStateCheck<K>> stateCondition : stateConditionsMap.entrySet()) {
                if (stateCondition.getValue().check(object)) {
                    registerStatesMap.put(object, stateCondition.getKey());
                    foundState = true;
                    break;
                }
            }
            if (!foundState) {
                registerStatesMap.put(object, defaultState);
            }
        }
    }

    public ObjectStateTracker<K, V> withState(V state, RegistrationStateCheck<K> condition){
        stateConditionsMap.put(state, condition);
        return this;
    }

    public ObjectStateTracker<K,V> elseState(V defaultState){
        this.defaultState = defaultState;
        return this;
    }

    public void updateStates(){} 

    @Override
    public String toString(){
        String str = "{Started=[";
        for(K register: registerStatesMap.keySet()){
            str += "Reg. of:" + register.toString() + ", ";
        }
        str = str.substring(0, str.length() - 2);

        str += "], FILLED[";
        for(Map.Entry<V, RegistrationStateCheck<K>> stateCondition: stateConditionsMap){

        }

        return str;
    }
}