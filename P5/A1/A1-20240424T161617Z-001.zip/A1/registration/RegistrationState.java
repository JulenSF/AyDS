package registration;
import java.util.*;

public enum RegistrationState{
	STARTED, FILLED, VALIDATED, PAYED, FINISHED, REJECTED;
}
