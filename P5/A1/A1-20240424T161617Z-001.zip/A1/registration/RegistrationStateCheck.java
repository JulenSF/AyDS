package registration;

public interface RegistrationStateCheck<T> {
    boolean check(T t);
}
