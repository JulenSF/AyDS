package registration;

public enum RegistrationState{
	STARTED, FILLED, VALIDATED, PAYED, FINISHED, REJECTED;
}
